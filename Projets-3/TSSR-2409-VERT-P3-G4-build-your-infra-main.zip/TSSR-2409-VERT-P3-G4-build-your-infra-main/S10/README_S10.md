# Objectifs de la semaine

Cette semaine nous avons décidé de mettre à niveau notre infrastructure:

- Nous avons déplacé notre serveur AD dans le bon Vlan.
- Nous avons mis à jour tout nos enregistrement DNS.
- Nous avons établis des règles de parefeu pour nos Vlan.
- Mise en place d'une page WEB intranet.


Nous avons également commencer à mettre en place un PC d'administration.