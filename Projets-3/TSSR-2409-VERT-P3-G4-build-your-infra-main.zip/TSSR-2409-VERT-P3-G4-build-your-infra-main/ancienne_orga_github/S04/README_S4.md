# S04

| **NOM** | **Roles** |
| :--: | :----------: |
| Bruno  | Product owner |
| Martin  | Scrum master |
| Lionel | Technicien  |
| Yohann | Technicien  |

## SOMMAIRE :
### Objectifs Principaux
### 1️⃣`Gestion Firewall`
* #### Mise en place de règles de pare-feu WAN, LAN, DMZ
* #### Utiliser les principes de gestion de règles
* #### mise en place de vlans via pfsense et tag
* #### mise en place des cartes réseaux sur les vlans attribués
* #### plan d'adressage + plan réseau
### 2️⃣`Identification des machines dans Proxmox` 
* #### Notes
* #### Nom de la machine
* #### Services/Rôles/Logiciels (détails)
* #### Source
* #### Tags
### Objectifs Secondaires
### 3️⃣`Sécurité - Télémétrie` 
* #### Mise en place via GPO
* #### Récupération des GPO => SRV
* #### Mise en place Via script
### Objectifs Optionnels
### 4️⃣`Mise en place de routeurs`
