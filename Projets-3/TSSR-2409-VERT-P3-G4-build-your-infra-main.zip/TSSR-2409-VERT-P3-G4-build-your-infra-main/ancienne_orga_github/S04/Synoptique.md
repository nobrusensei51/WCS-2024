# Schéma logique société Pharmgreen

![shema](https://github.com/user-attachments/assets/568d6aa6-fce0-4beb-b796-afd132391f67)
