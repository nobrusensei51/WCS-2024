# S03
## SOMMAIRE :
### 1️⃣`GPO`
* #### Sécurités
   * ##### Politique de mot de passe + Verrouillage de compte
   * ##### Restriction d'installation de logiciel pour les utilisateurs non-administrateurs
   * ##### Restriction des périphériques amovible
   * ##### Écran de veille avec mot de passe en sortie
   * ##### Blocage complet ou partiel au panneau de configuration
   * ##### Gestion de Windows update
* #### Standarts 
   * ##### Fond d'écran
   * ##### Mappage de lecteurs
   * ##### Gestion de l'alimentation
   * ##### Déploiement de logiciels .msi/.exe/GLPI Agent
   * ##### Configuration des paramètres du navigateur
### 2️⃣`GLPI`
* #### Instalation sur un serveur Debian (CLI)
* #### Synchronisation AD
* #### Gestion de parc : Inclusion des objets AD
### 3️⃣`Script`
* #### Instalation de GLPI => Debian 
### 4️⃣`Plan synoptique`
![Capture d'écran 2024-12-06 110448](https://github.com/user-attachments/assets/755cbbb0-6265-49ec-80d3-a24cba7ee144)


### 5️⃣`Tableau Vlan`





