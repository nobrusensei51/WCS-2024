## Liste du matériel prévisionnel

- 1 serveur ayant pour Rôle:
    - Serveur Active Directory;
    - Serveur DNS;
    - Serveur DHCP;
    - Serveur de VOIP.

- 1 Routeur ayant pour fonction:
    - De router tous les flux dans les bons services (par Vlans);
    - De Firewall (on passe soit par le routeur soit par un serveur);
    - De pont VPN (permettant au nomade de se connecter depuis l'extérieur aux services internes).

- Switchs + Antennes WIFI:
    - Les switchs permettrons de connecter en filaire les machines fixes de chaques services sur le bon Vlan;
    - Les antennes permettrons au PCs portables de se connecter de n'importe ou dans le batîment.

- Des téléphones fixes sur IP

- Imprimantes, scanners, fax

- PCs fixes et portables

- 1 Serveur de sauvegarde local + 1 Serveur de sauvegarde externalisé.

