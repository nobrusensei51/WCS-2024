# Schéma logique société Pharmgreen

![CONF PROJET3](https://github.com/user-attachments/assets/4ab3e209-3373-469d-8770-9bfc60bb52b5)

