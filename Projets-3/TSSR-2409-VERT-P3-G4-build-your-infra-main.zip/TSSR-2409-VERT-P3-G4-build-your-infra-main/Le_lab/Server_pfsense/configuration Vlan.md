# 🔥🧱Pfsense🧱🔥
## SOMMAIRE :
* ### 1) Vlan
* ### 2) Régles Firewall 

* ### 1) `Vlan`
#### Création des Vlan's via Pfsenses
![image](https://github.com/user-attachments/assets/9a12859c-1017-4e30-852e-3dfd59be1827)
#### Les Vlan Edités
![image](https://github.com/user-attachments/assets/0659db50-3d8b-46ff-bb02-d033508d8bd8)
#### Configuration des Vlan's 
#### Dans Interfaces : Interfaces Assignments => Add => choisir le Vlan souhaité et configurer
![ad1](https://github.com/user-attachments/assets/8b1b6ce1-8256-4aa1-b21e-29036bcc8530)





* ### 2) Régles Firewall
### 1️⃣ `Editions`

#### Dans Firewall : Rules => Choisir le Vlan souhaité
![Capture d'écran 2024-12-13 112748](https://github.com/user-attachments/assets/00120052-4d11-4bdb-ac91-7a9d034c8f2d)
























