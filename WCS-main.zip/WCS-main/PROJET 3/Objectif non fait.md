https://docs.google.com/spreadsheets/d/1gD5fyAN9Olu2De5SCk6L1eNOps8n7Q6Vp1-fZeFyTuI/edit?gid=1002311257#gid=1002311257
