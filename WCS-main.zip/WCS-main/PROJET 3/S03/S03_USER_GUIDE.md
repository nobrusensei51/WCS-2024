<details>
<summary><h1> 🎯 Création de ticket sur un compte utilisateur via GLPI<h1></summary>
<br>
  
📑 Connexion sur un compte utilisateur
---
![003](https://github.com/user-attachments/assets/7c46272c-778f-46fa-ba8d-31e5b8fd60f9)<br>

📑 Création d'un ticket
---
![004](https://github.com/user-attachments/assets/9c08904a-e19c-438d-99c0-643b0ed9fe45)<br>
---
![005](https://github.com/user-attachments/assets/7492bda0-3a30-4111-b8c9-e7053a177089)<br>
---
![006](https://github.com/user-attachments/assets/256e0ded-178e-4eb7-9a06-eaff91a1e264)<br>
---
![007](https://github.com/user-attachments/assets/090410c2-bf6b-4e5e-9187-0e6f90667ca5)<br>
---
![008](https://github.com/user-attachments/assets/bd91bc7c-502e-443e-b81d-5b2469b01c5d)<br>

---

📑 Réception de la solution et clos du ticket de l'utilisateur
---
![014](https://github.com/user-attachments/assets/ba16ef29-f360-40c5-8ecf-cdbb037c384e)<br>
---
![015](https://github.com/user-attachments/assets/1cb4aa23-ae56-4c5a-a01a-7b315a646813)<br>
---
![016](https://github.com/user-attachments/assets/727f4b31-1bfb-4279-a855-5f1910002970)<br>
---

</details>
