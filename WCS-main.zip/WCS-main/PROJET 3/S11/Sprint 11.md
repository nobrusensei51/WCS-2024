# PLANNING SEMAINE 11

## SPRINT 11 🏃‍♂️

| **Tâche**                                      | **Description**                                                                                                          |
|------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------|
| **???** 📊 | ??? |
| **???** 📊 | ??? |
| **???** 📊 | ??? |
| **???** 📊 | ??? |
| **???** 📊 | ??? |
| **???** 📊 | ??? |
| **???** 📊 | ??? |
| **???** 📊 | ??? |



## EQUIPES ET ROLES 🏢

| **Nom**          | **Rôle**          | **Description**                                     |
|-------------------|-------------------|-----------------------------------------------------|
| Julien | Product Owner 🎯  | Responsable de définir les besoins et priorités du projet. |
| NICOLAS | Scrum Master 🧑‍🤝‍🧑    | Garant du respect de la méthodologie Agile et facilitateur.|
| CHARLES | Technicien  💻    | Responsable des aspects techniques et de la mise en œuvre. |
| WILLIAM | Technicien 💻     | Responsable des aspects techniques et de la mise en œuvre. |


## OBJECTIS GLOBAL ET PERSO 🥇

GLOBAL :


PERSO :
