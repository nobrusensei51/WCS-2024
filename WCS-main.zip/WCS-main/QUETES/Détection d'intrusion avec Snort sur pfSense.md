### **Pour faire cette quête, je me suis aidé de ce tuto : https://www.youtube.com/watch?v=krznmeRvTJA**

# 🎯**Voici les étapes à suivre avec les screens** :

![CONFIG1](https://github.com/user-attachments/assets/24da1d12-562f-48c1-bdab-a8b3ab1d2ad9)<br>

![CONFIG2](https://github.com/user-attachments/assets/f0ecfc0d-ef0f-4ec5-b4c2-a40eafb75143)<br>

![CONFIG3](https://github.com/user-attachments/assets/aaaa3a93-f7cf-44b9-bdfb-d54ea6bde0e6)<br>

![CONFIG4](https://github.com/user-attachments/assets/f1ee4a6b-f8b8-4296-83e3-73c6e3c1220d)<br>

![CONFIG5](https://github.com/user-attachments/assets/a8587020-ba72-4d38-861c-d6955b5632a0)

---

# 🎯**Résultat du SSH** :

![SSH1](https://github.com/user-attachments/assets/cf47f4d6-e921-4803-b708-8d615020f3f3)<br><br>
![SSH2](https://github.com/user-attachments/assets/f646bc31-a0f3-43bd-9176-385b9e4f8a24)

---

# 🎯**Résultat du NMAP** :

![SCAN1](https://github.com/user-attachments/assets/d5abeecf-e823-4657-826b-3b33662ba33d)<br><br>
![SCAN2](https://github.com/user-attachments/assets/5513708b-2b1f-4d28-a6af-9673afa93b88)
